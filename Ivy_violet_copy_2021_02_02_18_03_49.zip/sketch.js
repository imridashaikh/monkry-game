var bananaImage,obstacleImage,obstaclegroup,background,score


function preload(){
  backImage=loadImage("jungle.jpg");
  player_running=loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
  bananaImage=loadImage("Banana.png");
  obstacleImage=loadImage("stone.png");
}






function setup() {
  createCanvas(400, 400);
  background=createsprite (400,400,200,50);
  background.addImage("jungle.jpg");
  jungle.velocityY=1;
  
   ground = createSprite(200,180,400,20);
  ground.x = ground.width /2;
  ground.velocityX = -4;
  
}

function draw() {
  background(220);
}